#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <iomanip>

int main() {
    int NX = 129;
    int NY = 129;

    const int Nalpha = 9;
    const double w[Nalpha] = {4.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36};
    const int Cx[Nalpha] = {0, 1, 0, -1, 0, 1, -1, -1, 1};
    const int Cy[Nalpha] = {0, 0, 1, 0, -1, 1, 1, -1, -1};

    int t_max = 1e5;
    double Re = 100;
    double tau = 0.8;
    double l = 128;
    double nu = (2 * tau - 1) / 6.0;
    double u_max = Re * nu / l;

    //3-D vector initialisation of f,f_equillibrium and f_colission

    std::vector<std::vector<std::vector<double>>> feq(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));
    std::vector<std::vector<std::vector<double>>> fcol(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));
    std::vector<std::vector<std::vector<double>>> f(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));

    std::vector<std::vector<double>> u(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> v(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> rho(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> u_old(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> v_old(NX, std::vector<double>(NY, 0));

    std::vector<std::vector<double>> psi(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> w_z(NX, std::vector<double>(NY, 0));

    bool converged = false;

    /////////////////////initialization///////////////
    for (int i = 0; i < NX; ++i) {
        for (int j = 0; j < NY; ++j) {
            rho[i][j] = 1.0;
            u[i][j] = 0.0;
            v[i][j] = 0.0;
        }
    }

    for (int i = 0; i < NX; ++i) {
        for (int j = 0; j < NY; ++j) {
            for (int k = 0; k < Nalpha; ++k) {
                feq[i][j][k] = w[k];
                fcol[i][j][k] = w[k];
                f[i][j][k] = w[k];
            }
        }
    }
    //////////////////////////////////////////////////
    double tolerance = 1e-8;
    int step = 100;

    /////////////////time-loop//////////////////
    for (int t = 0; t < t_max; ++t) {
        //////cal macroscopic variables////
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                rho[i][j] = 0.0;  // Reset before calculation
                u[i][j] = 0.0;
                v[i][j] = 0.0;
                for (int k = 0; k < Nalpha; ++k) {
                    rho[i][j] += f[i][j][k];
                    u[i][j] += f[i][j][k] * Cx[k];
                    v[i][j] += f[i][j][k] * Cy[k];
                }
                // Getting velocities
                if (rho[i][j] > 0) {
                    u[i][j] /= rho[i][j];
                    v[i][j] /= rho[i][j];
                }
            }
        }

        // Calculate stream function
        double dx = 1.0;
        double dy = 1.0;
        for (int i = 1; i < NX; i++) {
            psi[i][0] = psi[i - 1][0] + dy * v[i][0];  // Change uy_final to v
        }
        for (int j = 1; j < NY; j++) {
            psi[0][j] = psi[0][j - 1] - dx * u[0][j];  // Change ux_final to u
        }
        for (int i = 1; i < NX; i++) {
            for (int j = 1; j < NY; j++) {
                psi[i][j] = psi[i - 1][j] + dy * v[i][j];  // Change uy_final to v
            }
        }

        // Calculate vorticity (w_z)
        for (int i = 1; i < NX - 1; ++i) {
            for (int j = 1; j < NY - 1; ++j) {
                double du_dy = (u[i][j + 1] - u[i][j - 1]) / (2 * dy);
                double dv_dx = (v[i + 1][j] - v[i - 1][j]) / (2 * dx);
                w_z[i][j] = dv_dx - du_dy;
            }
        }
        ////////////////////////////////////

        if (t % step == 0 && t > 0) { // To Ensure this runs only after the first iteration
            double sum_u_diff2 = 0.0;
            double sum_v_diff2 = 0.0;
            double sum_u_old2 = 0.0;
            double sum_v_old2 = 0.0;
            for (int i = 0; i < NX; ++i) {
                for (int j = 0; j < NY; ++j) {
                    double u_diff = u[i][j] - u_old[i][j];
                    double v_diff = v[i][j] - v_old[i][j];
                    sum_u_diff2 += u_diff * u_diff;
                    sum_v_diff2 += v_diff * v_diff;
                    sum_u_old2 += u_old[i][j] * u_old[i][j];
                    sum_v_old2 += v_old[i][j] * v_old[i][j];
                }
            }

            double rms_u = std::sqrt(sum_u_diff2 / (sum_u_old2 > 0 ? sum_u_old2 : 1));  // Avoid division by zero
            double rms_v = std::sqrt(sum_v_diff2 / (sum_v_old2 > 0 ? sum_v_old2 : 1));  // Avoid division by zero

            std::cout << "Iteration: " << t << " RMS_u: " << rms_u << " RMS_v: " << rms_v << std::endl;

            if (rms_u < tolerance && rms_v < tolerance) {  // Use AND to ensure both conditions are met
                converged = true;
            } else {
                u_old = u;
                v_old = v;
            }
        }

        // Updating f equilibrium
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    double u_dot_c = Cx[k] * u[i][j] + Cy[k] * v[i][j];
                    double u_sq = u[i][j] * u[i][j] + v[i][j] * v[i][j];
                    feq[i][j][k] = w[k] * rho[i][j] * (1.0 + 3.0 * u_dot_c + 4.5 * u_dot_c * u_dot_c - 1.5 * u_sq);
                }
            }
        }

        // Collision step
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    fcol[i][j][k] = (1.0 - 1.0 / tau) * f[i][j][k] + 1.0 / tau * feq[i][j][k];
                }
            }
        }

        // Streaming step
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    int i_new = (i + Cx[k] + NX) % NX;
                    int j_new = (j + Cy[k] + NY) % NY;
                    f[i_new][j_new][k] = fcol[i][j][k];
                }
            }
        }

        // Top boundary
        for (int i = 0; i < NX; ++i) {
            f[i][NY - 1][4] = fcol[i][NY - 1][2];
            f[i][NY - 1][7] = fcol[i][NY - 1][5] - (1.0 / 6) * u_max;
            f[i][NY - 1][8] = fcol[i][NY - 1][6] + (1.0 / 6) * u_max;
        }

        // Bottom boundary
        for (int i = 0; i < NX; ++i) {
            f[i][0][2] = fcol[i][0][4];
            f[i][0][5] = fcol[i][0][7];
            f[i][0][6] = fcol[i][0][8];
        }

        // Left and right boundary
        for (int j = 0; j < NY; ++j) {
            f[0][j][1] = fcol[0][j][3];
            f[0][j][5] = fcol[0][j][7];
            f[0][j][8] = fcol[0][j][6];

            f[NX - 1][j][3] = fcol[NX - 1][j][1];
            f[NX - 1][j][7] = fcol[NX - 1][j][5];
            f[NX - 1][j][6] = fcol[NX - 1][j][8];
        }

         //Corner Treatment
        f[0][0][5] = fcol[0][0][7];
        f[0][0][1] = fcol[0][0][3];
        f[0][0][2] = fcol[0][0][4];

        // Bottom-right corner
        f[NX - 1][0][6] = fcol[NX - 1][0][8];
        f[NX - 1][0][3] = fcol[NX - 1][0][1];
        f[NX - 1][0][2] = fcol[NX - 1][0][4];

        // Top-left corner
        f[0][NY - 1][7] = fcol[0][NY - 1][5] - (1.0 / 6) * u_max;
        f[0][NY - 1][1] = fcol[0][NY - 1][3];
        f[0][NY - 1][4] = fcol[0][NY - 1][2];

       // Top-right corner
        f[NX - 1][NY - 1][8] = fcol[NX - 1][NY - 1][6] + (1.0 / 6) * u_max;
        f[NX - 1][NY - 1][3] = fcol[NX - 1][NY - 1][1];
        f[NX - 1][NY - 1][4] = fcol[NX - 1][NY - 1][2];

     /*   if (converged) {
            // Write results to Tecplot files
            std::ofstream file_u_vs_y("u_vs_y.dat");
            std::ofstream file_v_vs_x("v_vs_x.dat");
            std::ofstream file_psi("psi.dat");
            std::ofstream file_w_z("w_z.dat");
            std::ofstream file_rho("rho.dat"); // New output file for density

            if (file_u_vs_y.is_open()) {
                file_u_vs_y << "VARIABLES = \"y\", \"u\"\n";
                file_u_vs_y << "ZONE T=\"u vs y\"\n";
                file_u_vs_y << "I=" << NX << ", J=" << NY << "\n";
                for (int j = 0; j < NY; ++j) {
                    for (int i = 0; i < NX; ++i) {
                        file_u_vs_y << j << " " << u[64][j]/u_max << "\n";
                    }
                }
                file_u_vs_y.close();
            }

            if (file_v_vs_x.is_open()) {
                file_v_vs_x << "VARIABLES = \"x\", \"v\"\n";
                file_v_vs_x << "ZONE T=\"v vs x\"\n";
                file_v_vs_x << "I=" << NX << ", J=" << NY << "\n";
                for (int i = 0; i < NX; ++i) {
                    for (int j = 0; j < NY; ++j) {
                        file_v_vs_x << i << " " << v[i][64]/u_max<< "\n";
                    }
                }
                file_v_vs_x.close();
            }

            if (file_psi.is_open()) {
                file_psi << "VARIABLES = \"x\", \"y\", \"psi\"\n";
                file_psi << "ZONE T=\"Stream Function\"\n";
                file_psi << "I=" << NX << ", J=" << NY << "\n";
                for (int j = 0; j < NY; ++j) {
                    for (int i = 0; i < NX; ++i) {
                        file_psi << i << " " << j << " " << psi[i][j] << "\n";
                    }
                }
                file_psi.close();
            }

            if (file_w_z.is_open()) {
                file_w_z << "VARIABLES = \"x\", \"y\", \"w_z\"\n";
                file_w_z << "ZONE T=\"Vorticity\"\n";
                file_w_z << "I=" << NX << ", J=" << NY << "\n";
                for (int j = 0; j < NY; ++j) {
                    for (int i = 0; i < NX; ++i) {
                        file_w_z << i << " " << j << " " << w_z[i][j] << "\n";
                    }
                }
                file_w_z.close();
            }

            // New file output for density
            if (file_rho.is_open()) {
                file_rho << "VARIABLES = \"x\", \"y\", \"rho\"\n";
                file_rho << "ZONE T=\"Density\"\n";
                file_rho << "I=" << NX << ", J=" << NY << "\n";
                for (int j = 0; j < NY; ++j) {
                    for (int i = 0; i < NX; ++i) {
                        file_rho << i << " " << j << " " << rho[i][j] << "\n";
                    }
                }
                file_rho.close();
            }

            break; // Exit loop after writing files
        }
    }

    std::ofstream oFile;
    oFile.open("contour.dat");
    oFile<<"ZONE\tI="<<129<<"\t"<<"J="<<129<<std::endl;
    for (int iY = 0; iY < NY; ++iY)
    {
        for (int iX = 0; iX < NX; ++iX)
        {
            oFile<<iX<<"\t"<<iY<<"\t"<<rho[iX][iY]<<"\t"<<u[iX][iY]<<"\t"<<v[iX][iY]<<std::endl;
        }
    }
    oFile.close();

    return 0;
}  */

  if (converged) {
    // Write results to Tecplot files
    std::ofstream file_u_vs_y("u_vs_y.dat");
    std::ofstream file_v_vs_x("v_vs_x.dat");
    std::ofstream file_psi("psi.dat");
    std::ofstream file_w_z("w_z.dat");
    std::ofstream file_rho("rho.dat"); // New output file for density

    if (file_u_vs_y.is_open()) {
        file_u_vs_y << "VARIABLES = \"y/NY\", \"u/u_max\"\n";
        file_u_vs_y << "ZONE T=\"u vs y (midplane)\"\n";
        file_u_vs_y << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            double y_scaled = static_cast<double>(j) / NY; // Scale y by NY
            file_u_vs_y << y_scaled << " " << u[64][j] / u_max << "\n"; // Normalize u
        }
        file_u_vs_y.close();
    }

    if (file_v_vs_x.is_open()) {
        file_v_vs_x << "VARIABLES = \"x/NX\", \"v/v_max\"\n";
        file_v_vs_x << "ZONE T=\"v vs x (midplane)\"\n";
        file_v_vs_x << "I=" << NX << ", J=" << NY << "\n";
        for (int i = 0; i < NX; ++i) {
            double x_scaled = static_cast<double>(i) / NX; // Scale x by NX
            file_v_vs_x << x_scaled << " " << v[i][64] / u_max << "\n"; // Normalize v
        }
        file_v_vs_x.close();
    }

    if (file_psi.is_open()) {
        file_psi << "VARIABLES = \"x\", \"y\", \"psi\"\n";
        file_psi << "ZONE T=\"Stream Function\"\n";
        file_psi << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_psi << i << " " << j << " " << psi[i][j] << "\n";
            }
        }
        file_psi.close();
    }

    if (file_w_z.is_open()) {
        file_w_z << "VARIABLES = \"x\", \"y\", \"w_z\"\n";
        file_w_z << "ZONE T=\"Vorticity\"\n";
        file_w_z << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_w_z << i << " " << j << " " << w_z[i][j] << "\n";
            }
        }
        file_w_z.close();
    }

    // New file output for density
    if (file_rho.is_open()) {
        file_rho << "VARIABLES = \"x\", \"y\", \"rho\"\n";
        file_rho << "ZONE T=\"Density\"\n";
        file_rho << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_rho << i << " " << j << " " << rho[i][j] << "\n";
            }
        }
        file_rho.close();
    }

    break; // Exit loop after writing files
}}

std::ofstream oFile;
oFile.open("contour.dat");
oFile << "ZONE\tI=" << 129 << "\t"
      << "J=" << 129 << std::endl;
for (int iY = 0; iY < NY; ++iY) {
    for (int iX = 0; iX < NX; ++iX) {
        oFile << iX << "\t" << iY << "\t" << rho[iX][iY] << "\t" << u[iX][iY] << "\t" << v[iX][iY] << std::endl;
    }
}
oFile.close();

return 0;

};
