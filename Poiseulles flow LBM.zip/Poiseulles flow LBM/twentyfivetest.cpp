//Poiseulles Flow
//Appended from NEBB CODE

#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <iomanip>

int main() {
    int NX = 200;
    int NY = 20;

    const int Nalpha = 9;
    const double w[Nalpha] = {4.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 9, 1.0 / 36, 1.0 / 36, 1.0 / 36, 1.0 / 36};
    const int Cx[Nalpha] = {0, 1, 0, -1, 0, 1, -1, -1, 1};
    const int Cy[Nalpha] = {0, 0, 1, 0, -1, 1, 1, -1, -1};

    int t_max = 1e7;
    double Re = 10.0;
    double tau = 0.8;
    double l = 20;
    double nu = (2 * tau - 1) / 6.0;
            double H=NY-1;

    double u_max = Re * nu / H;

    double rho_top_boundary[NX-1][NY-1];
    double rho_bottom_boundary[NX-1][NY-1];
    double rho_left_boundary[NX-1][NY-1];
        double rho_right_boundary[NX-1][NY-1];
        double ux_right[NX-1][NY-1];
        double u_exact;

      //3-D vector initialisation of f,f_equillibrium and f_colission

    std::vector<std::vector<std::vector<double>>> feq(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));
    std::vector<std::vector<std::vector<double>>> fcol(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));
    std::vector<std::vector<std::vector<double>>> f(NX, std::vector<std::vector<double>>(NY, std::vector<double>(Nalpha, 0)));

    std::vector<std::vector<double>> u(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> v(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> rho(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> u_old(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> v_old(NX, std::vector<double>(NY, 0));

    std::vector<std::vector<double>> psi(NX, std::vector<double>(NY, 0));
    std::vector<std::vector<double>> w_z(NX, std::vector<double>(NY, 0));

    bool converged = false;

    /////////////////////initialization///////////////
    for (int i = 0; i < NX; ++i) {
        for (int j = 0; j < NY; ++j) {
            rho[i][j] = 1.0;
            u[i][j] = 0.0;
            v[i][j] = 0.0;
        }
    }

    for (int i = 0; i < NX; ++i) {
        for (int j = 0; j < NY; ++j) {
            for (int k = 0; k < Nalpha; ++k) {
                feq[i][j][k] = w[k];
                fcol[i][j][k] = w[k];
                f[i][j][k] = w[k];
            }
        }
    }
    double tolerance = 1e-6;
    int step = 100;

    /////////////////time-loop//////////////////
    for (int t = 0; t < t_max; ++t) {
        //////cal macroscopic variables////
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                rho[i][j] = 0.0;  // Reset before calculation
                u[i][j] = 0.0;
                v[i][j] = 0.0;
                for (int k = 0; k < Nalpha; ++k) {
                    rho[i][j] += f[i][j][k];
                    u[i][j] += f[i][j][k] * Cx[k];
                    v[i][j] += f[i][j][k] * Cy[k];
                }
                // Getting velocities
                if (rho[i][j] > 0) {
                    u[i][j] /= rho[i][j];
                    v[i][j] /= rho[i][j];
                }
            }
        }

        // Calculate stream function
        double dx = 1.0;
        double dy = 1.0;
        for (int i = 1; i < NX; i++) {
            psi[i][0] = psi[i - 1][0] + dy * v[i][0];  // Change uy_final to v
        }
        for (int j = 1; j < NY; j++) {
            psi[0][j] = psi[0][j - 1] - dx * u[0][j];  // Change ux_final to u
        }
        for (int i = 1; i < NX; i++) {
            for (int j = 1; j < NY; j++) {
                psi[i][j] = psi[i - 1][j] + dy * v[i][j];  // Change uy_final to v
            }
        }

        // Calculate vorticity (w_z)
        for (int i = 1; i < NX - 1; ++i) {
            for (int j = 1; j < NY - 1; ++j) {
                double du_dy = (u[i][j + 1] - u[i][j - 1]) / (2 * dy);
                double dv_dx = (v[i + 1][j] - v[i - 1][j]) / (2 * dx);
                w_z[i][j] = dv_dx - du_dy;
            }
        }

        if (t % step == 0 && t > 0) { // To Ensure this runs only after the first iteration
            double sum_u_diff2 = 0.0;
            double sum_v_diff2 = 0.0;
            double sum_u_old2 = 0.0;
            double sum_v_old2 = 0.0;
            for (int i = 0; i < NX; ++i) {
                for (int j = 0; j < NY; ++j) {
                    double u_diff = u[i][j] - u_old[i][j];
                    double v_diff = v[i][j] - v_old[i][j];
                    sum_u_diff2 += u_diff * u_diff;
                    sum_v_diff2 += v_diff * v_diff;
                    sum_u_old2 += u_old[i][j] * u_old[i][j];
                    sum_v_old2 += v_old[i][j] * v_old[i][j];
                }
            }

            double rms_u = std::sqrt(sum_u_diff2 / (sum_u_old2 > 0 ? sum_u_old2 : 1));  // Avoid division by zero
            double rms_v = std::sqrt(sum_v_diff2 / (sum_v_old2 > 0 ? sum_v_old2 : 1));  // Avoid division by zero

            std::cout << "Iteration: " << t << " RMS_u: " << rms_u << " RMS_v: " << rms_v << std::endl;

            if (rms_u < tolerance || rms_v < tolerance) {  // Use AND to ensure both conditions are met
                converged = true;
            } else {
                u_old = u;
                v_old = v;
            }
        }

        // Updating f equilibrium
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    double u_dot_c = Cx[k] * u[i][j] + Cy[k] * v[i][j];
                    double u_sq = u[i][j] * u[i][j] + v[i][j] * v[i][j];
                    feq[i][j][k] = w[k] * rho[i][j] * (1.0 + 3.0 * u_dot_c + 4.5 * u_dot_c * u_dot_c - 1.5 * u_sq);
                }
            }
        }

        // Collision step
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    fcol[i][j][k] = (1.0 - 1.0 / tau) * f[i][j][k] + 1.0 / tau * feq[i][j][k];
                }
            }
        }

        // Streaming step
        for (int i = 0; i < NX; ++i) {
            for (int j = 0; j < NY; ++j) {
                for (int k = 0; k < Nalpha; ++k) {
                    int inext = (i + Cx[k] + NX) % NX;
                    int jnext = (j + Cy[k] + NY) % NY;
                    f[inext][jnext][k] = fcol[i][j][k];
                }
            }
        }

    // Top boundary
        for (int i = 0; i < NX; ++i) {

            double uy_top = 0.0; // Top wall moves with u=u_max
            double ux_top = 0;

            // Calculate the density on the bottom wall using the specified formula
             rho[i][NY-1] = (1.0 / (1.0 + uy_top)) * (f[i][NY-1][0] + f[i][NY-1][1] + f[i][NY-1][3] + 2.0 * (f[i][NY-1][2] + f[i][NY-1][6] + f[i][NY-1][5]));

            // f4 - f4eq = f2 - f2eq
           // double f4_eq = w[4] * rho_top_boundary * (1.0 + 3.0 * (ux_top * Cx[4] + uy_top * Cy[4]));
           // double f2_eq = w[2] * rho_top_boundary * (1.0 + 3.0 * (ux_top * Cx[2] + uy_top * Cy[2]));
            f[i][NY-1][4] = f[i][NY-1][2]-(2/3)*rho[i][NY-1]*uy_top;

            f[i][NY-1][7] =  f[i][NY-1][5] +0.5*(f[i][NY-1][1] - f[i][NY-1][3]) - 1/6*rho[i][NY-1]*uy_top-0.5*rho[i][NY-1]*ux_top;

            f[i][NY-1][8] =  f[i][NY-1][6] +0.5*(f[i][NY-1][3] - f[i][NY-1][1]) - 1/6*rho[i][NY-1]*uy_top+0.5*rho[i][NY-1]*ux_top;
        }

        ////////////bottom boundary/////////////
  for (int i = 0; i < NX; ++i) {
            double ux = 0.0; // Bottom wall is stationary
            double uy = 0.0; // Bottom wall is stationary

            // Calculate the density on the bottom wall using the specified formula
             rho[i][0] = (1.0 / (1.0 - uy)) * (f[i][0][0] + f[i][0][1] + f[i][0][3] + 2.0 * (f[i][0][4] + f[i][0][7] + f[i][0][8]));

            // NEBB conditions
            // f2 - f2eq = f4 - f4eq
           // double f2_eq = w[2] * rho_bottom_boundary * (1.0 + 3.0 * (ux * Cx[2] + uy * Cy[2]));
            // double f4_eq = w[4] * rho_bottom_boundary * (1.0 + 3.0 * (ux * Cx[4] + uy * Cy[4]));
            f[i][0][2] = f[i][0][4] + (2/3)*rho[i][0]*uy;

             f[i][0][5] =  f[i][0][7] -0.5*(f[i][0][1] - f[i][0][3]) + 1/6*rho[i][0]*uy+0.5*rho[i][0]*ux;

            f[i][0][6] =  f[i][0][8] -(0.5*(f[i][0][3] - f[i][0][1])) + 1/6*rho[i][0]*uy+0.5*rho[i][0]*ux;
        }


            /////////Left boundary//////
        for (int j = 1; j < NY-1; ++j) {

            double ux_left = u_max/1.5; // Left wall is stationary
            double uy = 0.0; // Left wall is stationary

            // Calculate the density on the bottom wall using the specified formula
             rho[0][j] = (1.0 / (1.0 - ux_left))* (f[0][j][0] + f[0][j][2] + f[0][j][4] + 2.0 * (f[0][j][3] + f[0][j][6] + f[0][j][7]));

            // f1 - f1eq = f3 - f3eq
           // double f1_eq = w[1] * rho_left_boundary * (1.0 + 3.0 * (ux * Cx[1] + uy * Cy[1]));
            //double f3_eq = w[3] * rho_left_boundary * (1.0 + 3.0 * (ux * Cx[3] + uy * Cy[3]));
            f[0][j][1] = f[0][j][3] + (2/3)*rho[0][j]*ux_left;

            f[0][j][5] =  f[0][j][7] -(0.5*(f[0][j][2] - f[0][j][4])) + 1/6*rho[0][j]*ux_left;

            f[0][j][8] =  f[0][j][6] + (0.5*(f[0][j][2] - f[0][j][4])) + 1/6*rho[0][j]*ux_left;
        }


       /////////Right boundary//////
        for (int j = 1; j < NY-1; ++j)
            {
            ux_right[NX-1][j]=(f[NX-1][j][0]+f[NX-1][j][2]+f[NX-1][j][4]+((2*f[NX-1][j][1]+f[NX-1][j][5]+f[NX-1][j][8])/(rho[NX-1][j])))-1;
            double uy_right =(1/3)*(4*v[NX-1][j-1]-v[NX-1][j-2]);

            // Calculate the density on the bottom wall using the specified formula
             rho[NX-1][j] = 1.0;   //Atmospheric conditions

            // f3 - f3eq = f1 - f1eq
            //double f1_eq = w[1] * rho_right_boundary * (1.0 + 3.0 * (ux * Cx[1] + uy * Cy[1]));
            //double f3_eq = w[3] * rho_right_boundary * (1.0 + 3.0 * (ux * Cx[3] + uy * Cy[3]));
            f[NX-1][j][3] = f[NX-1][j][1]-((2/3)*rho[NX-1][j]*ux_right[NX-1][j]);

            f[NX-1][j][7] = f[NX-1][j][5] +0.5*(f[NX-1][j][2] - f[NX-1][j][4]) - 1/6*rho[NX-1][j]*ux_right[NX-1][j];

            f[NX-1][j][6] =  f[NX-1][j][8] -0.5*(f[NX-1][j][2] - f[NX-1][j][4]) - (1/6*rho[NX-1][j]*ux_right[NX-1][j])+0.5*rho[NX-1][j]*uy_right;

        }

        ///////Corner Treatment////////////////
     //Bottom left corner//
    /* u[0][0]=0;
     v[0][0]=0;
        f[0][0][1]=f[0][0][3]+2/3*rho[0][0]*u[0][0];
        f[0][0][2]=f[0][0][4]+2/3*rho[0][0]*v[0][0];
        f[0][0][5]=f[0][0][7]+1/6*rho[0][0]*(u[0][0]+v[0][0]);
        f[0][0][6]=1/12*rho[0][0]*(-u[0][0]+v[0][0]);
        f[0][0][8]=1/12*rho[0][0]*(u[0][0]-v[0][0]);


      //Top Left corner//
    u[0][NY-1]=u_max;
     v[0][NY]=0;
        f[0][NY-1][1]=f[0][NY-1][3]+2/3*rho[0][NY-1]*u[0][NY-1];
        f[0][NY-1][4]=f[0][NY-1][2]-2/3*rho[0][NY-1]*v[0][NY-1];
        f[0][NY-1][8]=f[0][NY-1][6]+1/6*rho[0][NY-1]*(u[0][NY-1]-v[0][NY-1]);
        f[0][NY-1][5]=1/12*rho[0][NY-1]*(u[0][NY-1]+v[0][NY-1]);
        f[0][NY-1][7]=1/12*rho[0][NY-1]*(-u[0][NY-1]-v[0][NY-1]);

     //Top Right//
    u[NX-1][NY-1]=u_max;
     v[NX-1][NY-1]=0;
        f[NX-1][NY-1][3]=f[NX-1][NY-1][1]-2/3*rho[NX-1][NY-1]*u[NX-1][NY-1];
        f[NX-1][NY-1][4]=f[NX-1][NY-1][2]-2/3*rho[NX-1][NY-1]*v[NX-1][NY-1];
        f[NX-1][NY-1][7]=f[NX-1][NY-1][5]-1/6*rho[NX-1][NY-1]*(u[NX-1][NY-1]+v[NX-1][NY-1]);
        f[NX-1][NY-1][6]=1/12*rho[NX-1][NY-1]*(-u[NX-1][NY-1]+v[NX-1][NY-1]);
        f[NX-1][NY-1][8]=1/12*rho[NX-1][NY-1]*(u[NX-1][NY-1]-v[NX-1][NY-1]);


     //Bottom right//
    u[NX-1][0]=0;
     v[NX-1][0]=0;
        f[NX-1][0][2]=f[NX-1][0][4]+2/3*rho[NX-1][0]*v[NX-1][0];
        f[NX-1][0][3]=f[NX-1][0][1]-2/3*rho[NX-1][0]*u[NX-1][0];
        f[NX-1][0][6]=f[NX-1][0][8]-1/6*rho[NX-1][0]*(u[NX-1][0]-v[NX][0]);
        f[NX-1][0][5]=1/12*rho[NX-1][0]*(u[NX-1][0]+v[NX-1][0]);
        f[NX-1][0][7]=1/12*rho[NX-1][0]*(-u[NX-1][0]-v[NX-1][0]);*/

        ////////////////////////////////////CORNER TREATMENT/////////////////////////////////////////////////
        //BOTTOM LEFT
        f[0][0][1]=f[0][0][3];
        f[0][0][2]=f[0][0][4];
        f[0][0][5]=f[0][0][7];
        f[0][0][6]=0;
        f[0][0][8]=0;
         f[0][0][0]=rho[0][1]-(f[0][0][1]+f[0][0][2]+f[0][0][3]+f[0][0][4]+f[0][0][5]+f[0][0][6]+f[0][0][7]+f[0][0][8]);

      //Top Left corner//

        f[0][NY-1][1]=f[0][NY-1][3];
        f[0][NY-1][4]=f[0][NY-1][2];
        f[0][NY-1][8]=f[0][NY-1][6];
        f[0][NY-1][5]=0;
        f[0][NY-1][7]=0;
        f[0][NY-1][0]=rho[0][NY-2]-(f[0][NY-1][1]+f[0][NY-1][2]+f[0][NY-1][3]+f[0][NY-1][4]+f[0][NY-1][5]+f[0][NY-1][6]+f[0][NY-1][7]+f[0][NY-1][8]);

     //Top Right//

        f[NX-1][NY-1][3]=f[NX-1][NY-1][1];
        f[NX-1][NY-1][4]=f[NX-1][NY-1][2];
        f[NX-1][NY-1][7]=f[NX-1][NY-1][5];
        f[NX-1][NY-1][6]=0;
        f[NX-1][NY-1][8]=0;
        f[NX-1][NY-1][0]=rho[NX-1][NY-2]-(f[NX-1][NY-1][1]+f[NX-1][NY-1][2]+f[NX-1][NY-1][3]+f[NX-1][NY-1][4]+f[NX-1][NY-1][5]+f[NX-1][NY-1][6]+f[NX-1][NY-1][7]+f[NX-1][NY-1][8]);


     //Bottom right//
   // u[NX-1][0]=0;
    // v[NX-1][0]=0;
        f[NX-1][0][2]=f[NX-1][0][4];
        f[NX-1][0][3]=f[NX-1][0][1];
        f[NX-1][0][6]=f[NX-1][0][8];
        f[NX-1][0][5]=0;
        f[NX-1][0][7]=0;
        f[NX-1][0][0]=rho[NX-1][1]-(f[NX-1][0][1]+f[NX-1][0][2]+f[NX-1][0][3]+f[NX-1][0][4]+f[NX-1][0][5]+f[NX-1][0][6]+f[NX-1][0][7]+f[NX-1][0][8]);


   /*     if (converged) {
            std::cout << "Converged at iteration " << t << std::endl;
            break;
        }
    }

    std::ofstream outfile;
    outfile.open("velocity.dat");

    for (int j = 0; j < NY; ++j) {
        outfile << std::setw(10) << std::fixed << std::setprecision(6) << (j + 1) / static_cast<double>(NY);
        outfile << std::setw(15) << u[NX / 2][j];
        outfile << std::setw(15) << v[NX / 2][j];
        outfile << std::setw(15) << psi[NX / 2][j];
        outfile << std::setw(15) << w_z[NX / 2][j] << std::endl;
    }
    outfile.close();
    return 0;
}*/

  /* if (converged) {
    // Write results to Tecplot files
    std::ofstream file_u_vs_y("u_vs_y.dat");
    std::ofstream file_v_vs_x("v_vs_x.dat");
    std::ofstream file_psi("psi.dat");
    std::ofstream file_w_z("w_z.dat");
    std::ofstream file_rho("rho.dat"); // New output file for density

    if (file_u_vs_y.is_open()) {
        file_u_vs_y << "VARIABLES = \"y/NY\", \"u/u_max\"\n";
        for (int j = 0; j < NY; ++j) {
            double y_scaled = static_cast<double>(j) / NY; // Scale y by NY
            file_u_vs_y << y_scaled << " " << u[64][j] / u_max << "\n"; // Normalize u
        }
        file_u_vs_y.close();
    }

    if (file_v_vs_x.is_open()) {
        file_v_vs_x << "VARIABLES = \"x/NX\", \"v/v_max\"\n";
        for (int i = 0; i < NX; ++i) {
            double x_scaled = static_cast<double>(i) / NX; // Scale x by NX
            file_v_vs_x << x_scaled << " " << v[i][64] / u_max << "\n"; // Normalize v
        }
        file_v_vs_x.close();
    }

    if (file_psi.is_open()) {
        file_psi << "VARIABLES = \"x\", \"y\", \"psi\"\n";
        file_psi << "ZONE T=\"Stream Function\"\n";
        file_psi << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_psi << i << " " << j << " " << psi[i][j] << "\n";
            }
        }
        file_psi.close();
    }

    if (file_w_z.is_open()) {
        file_w_z << "VARIABLES = \"x\", \"y\", \"w_z\"\n";
        file_w_z << "ZONE T=\"Vorticity\"\n";
        file_w_z << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_w_z << i << " " << j << " " << w_z[i][j] << "\n";
            }
        }
        file_w_z.close();
    }

    // New file output for density
    if (file_rho.is_open()) {
        file_rho << "VARIABLES = \"x\", \"y\", \"rho\"\n";
        file_rho << "ZONE T=\"Density\"\n";
        file_rho << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_rho << i << " " << j << " " << rho[i][j] << "\n";
            }
        }
        file_rho.close();
    }

    break; // Exit loop after writing files
}}

std::ofstream oFile;
oFile.open("contour.dat");
oFile << "ZONE\tI=" << 129 << "\t"
      << "J=" << 129 << std::endl;
for (int iY = 0; iY < NY; ++iY) {
    for (int iX = 0; iX < NX; ++iX) {
        oFile << iX << "\t" << iY << "\t" << rho[iX][iY] << "\t" << u[iX][iY] << "\t" << v[iX][iY] << std::endl;
    }
}
oFile.close();

return 0;

};*/

  if (converged) {
    // Write results to Tecplot files
    std::ofstream file_u_vs_y("u_vs_y.dat");
    std::ofstream file_v_vs_x("v_vs_x.dat");
    std::ofstream file_psi("psi.dat");
    std::ofstream file_w_z("w_z.dat");
    std::ofstream file_rho("rho.dat"); //  output file for density

    if (file_u_vs_y.is_open()) {
        file_u_vs_y << "VARIABLES = \"y/NY\", \"u/u_max\", \"u_exact/u_max\"\n";
        for (int j = 0; j < NY; ++j) {
         //   double y_scaled = static_cast<double>(j) / NY; // Scale y by NY
           // double y = y_scaled * H; // Scale y to actual height H
            double u_exact = 4*u_max * ((j/H) - (j / H) * ( j/ H)); // Calculate u_exact
            file_u_vs_y << j/H << " " << u[100][j] / u_max << " " << u_exact / u_max << "\n"; // Normalize u and u_exact
        }
        file_u_vs_y.close();
    }

    if (file_v_vs_x.is_open()) {
        file_v_vs_x << "VARIABLES = \"x/NX\", \"v/v_max\"\n";
        for (int i = 0; i < NX; ++i) {
            double x_scaled = static_cast<double>(i) / NX; // Scale x by NX
            file_v_vs_x << x_scaled << " " << v[i][100] / u_max << "\n"; // Normalize v
        }
        file_v_vs_x.close();
    }

    if (file_psi.is_open()) {
        file_psi << "VARIABLES = \"x\", \"y\", \"psi\"\n";
        file_psi << "ZONE T=\"Stream Function\"\n";
        file_psi << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_psi << i << " " << j << " " << psi[i][j] << "\n";
            }
        }
        file_psi.close();
    }

    if (file_w_z.is_open()) {
        file_w_z << "VARIABLES = \"x\", \"y\", \"w_z\"\n";
        file_w_z << "ZONE T=\"Vorticity\"\n";
        file_w_z << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_w_z << i << " " << j << " " << w_z[i][j] << "\n";
            }
        }
        file_w_z.close();
    }

    // New file output for density
    if (file_rho.is_open()) {
        file_rho << "VARIABLES = \"x\", \"y\", \"rho\"\n";
        file_rho << "ZONE T=\"Density\"\n";
        file_rho << "I=" << NX << ", J=" << NY << "\n";
        for (int j = 0; j < NY; ++j) {
            for (int i = 0; i < NX; ++i) {
                file_rho << i << " " << j << " " << rho[i][j] << "\n";
            }
        }
        file_rho.close();
    }

    break; // Exit loop after writing files
}}

std::ofstream oFile;
oFile.open("contour.dat");
oFile << "ZONE\tI=" << 200 << "\t"
      << "J=" << 20 << std::endl;
for (int iY = 0; iY < NY; ++iY) {
    for (int iX = 0; iX < NX; ++iX) {
        oFile << iX << "\t" << iY << "\t" << rho[iX][iY] << "\t" << u[iX][iY] << "\t" << v[iX][iY] << std::endl;
    }
}
oFile.close();

return 0;

};

   /* if (converged) {
        // Write results to Tecplot files
        std::ofstream file_u_vs_y("u_vs_y.dat");
        std::ofstream file_v_vs_x("v_vs_x.dat");
        std::ofstream file_psi("psi.dat");
        std::ofstream file_w_z("w_z.dat");
        std::ofstream file_rho("rho.dat"); //  output file for density

        if (file_u_vs_y.is_open()) {
            file_u_vs_y << "VARIABLES = \"y/NY\", \"u/u_max\", \"u_exact/u_max\"\n";
            for (int j = 0; j < NY; ++j) {
                double y = static_cast<double>(j) / NY * H; // Scale y to actual height H
                double u_exact = 4 * u_max * ((y / H) - (y / H) * (y / H)); // Calculate u_exact
                file_u_vs_y << y / H << " " << u[100][j] / u_max << " " << u_exact / u_max << "\n"; // Normalize u and u_exact
            }
            file_u_vs_y.close();
        } else {
            std::cerr << "Unable to open file_u_vs_y\n";
        }

        if (file_v_vs_x.is_open()) {
            file_v_vs_x << "VARIABLES = \"x/NX\", \"v/v_max\"\n";
            for (int i = 0; i < NX; ++i) {
                double x_scaled = static_cast<double>(i) / NX; // Scale x by NX
                file_v_vs_x << x_scaled << " " << v[i][64] / u_max << "\n"; // Normalize v
            }
            file_v_vs_x.close();
        } else {
            std::cerr << "Unable to open file_v_vs_x\n";
        }

        if (file_psi.is_open()) {
            file_psi << "VARIABLES = \"x\", \"y\", \"psi\"\n";
            file_psi << "ZONE T=\"Stream Function\"\n";
            file_psi << "I=" << NX << ", J=" << NY << "\n";
            for (int j = 0; j < NY; ++j) {
                for (int i = 0; i < NX; ++i) {
                    file_psi << i << " " << j << " " << psi[i][j] << "\n";
                }
            }
            file_psi.close();
        } else {
            std::cerr << "Unable to open file_psi\n";
        }

        if (file_w_z.is_open()) {
            file_w_z << "VARIABLES = \"x\", \"y\", \"w_z\"\n";
            file_w_z << "ZONE T=\"Vorticity\"\n";
            file_w_z << "I=" << NX << ", J=" << NY << "\n";
            for (int j = 0; j < NY; ++j) {
                for (int i = 0; i < NX; ++i) {
                    file_w_z << i << " " << j << " " << w_z[i][j] << "\n";
                }
            }
            file_w_z.close();
        } else {
            std::cerr << "Unable to open file_w_z\n";
        }

        if (file_rho.is_open()) {
            file_rho << "VARIABLES = \"x\", \"y\", \"rho\"\n";
            file_rho << "ZONE T=\"Density\"\n";
            file_rho << "I=" << NX << ", J=" << NY << "\n";
            for (int j = 0; j < NY; ++j) {
                for (int i = 0; i < NX; ++i) {
                    file_rho << i << " " << j << " " << rho[i][j] << "\n";
                }
            }
            file_rho.close();
        } else {
            std::cerr << "Unable to open file_rho\n";
        }
    }}

    std::ofstream oFile;
    oFile.open("contour.dat");
    if (oFile.is_open()) {
        oFile << "ZONE\tI=" << NX << "\t"
              << "J=" << NY << std::endl;
        for (int iY = 0; iY < NY; ++iY) {
            for (int iX = 0; iX < NX; ++iX) {
                oFile << iX << "\t" << iY << "\t" << rho[iX][iY] << "\t" << u[iX][iY] << "\t" << v[iX][iY] << std::endl;
            }
        }
        oFile.close();
    } else {
        std::cerr << "Unable to open contour.dat\n";
    }

    return 0;
}*/


